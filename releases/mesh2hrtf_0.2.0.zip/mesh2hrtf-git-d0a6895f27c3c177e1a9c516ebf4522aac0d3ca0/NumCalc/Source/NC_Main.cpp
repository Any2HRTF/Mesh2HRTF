/*===========================================================================*\
 *                                                                            *
 *                                 Mesh2HRTF                                  *
 *                Copyright (C) 2015 by Harald Ziegelwanger,                  *
 *        Acoustics Research Institute, Austrian Academy of Sciences          *
 *                        mesh2hrtf.sourceforge.net                           *
 *                                                                            *
 *--------------------------------------------------------------------------- *
 *                                                                            *
 *  Mesh2HRTF is licensed under the GNU Lesser General Public License as      *
 *  published by the Free Software Foundation, either version 3 of            *
 *  the License, or (at your option) any later version.                       *
 *                                                                            *
 *  Mesh2HRTF is distributed in the hope that it will be useful,              *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the              *
 *  GNU Lesser General Public License for more details.                       *
 *                                                                            *
 *  You should have received a copy of the GNU LesserGeneral Public           *
 *  License along with Mesh2HRTF. If not, see                                 *
 *  <http://www.gnu.org/licenses/lgpl.html>.                                  *
 *                                                                            *
 *  If you use Mesh2HRTF:                                                     *
 *  - Provide credits:                                                        *
 *    "Mesh2HRTF, H. Ziegelwanger, ARI, OEAW (mesh2hrtf.sourceforge.net)"     *
 *  - In your publication, cite both articles:                                *
 *    [1] Ziegelwanger, H., Kreuzer, W., and Majdak, P. (2015). "Mesh2HRTF:   *
 *        Open-source software package for the numerical calculation of       *
 *        head-related transfer functions," in Proceedings of the 22nd        *
 *        ICSV, Florence, IT.                                                 *
 *    [2] Ziegelwanger, H., Majdak, P., and Kreuzer, W. (2015). "Numerical    *
 *        calculation of listener-specific head-related transfer functions    *
 *        and sound localization: Microphone model and mesh discretization,"  *
 *        The Journal of the Acoustical Society of America, 138, 208-222.     *
 *                                                                            *
 \*===========================================================================*/



/*===========================================================================*\
 *                                                                            *
 *  File name:      NC_Main.cpp                                               *
 *  Description:    main and control programs of NumCalc (Acoustic BEM for    *
 *  the calculation of head-related transfer functions)                       *
 *  Author:         H. Ziegelwanger, W. Kreuzer and Z.S. Chen                 *
 *                                                                            *
 \*===========================================================================*/



//================================= I N C L U D E S ==================================
// local includes                                                                   //
#include"NC_ConstantsVariables.h"                                                   //
#include"NC_TypeDefinition.h"                                                       //
#include"NC_Arrays.h"                                                               //
#include"NC_IntegrationConstants.h"                                                 //
//                                                                                  //
// system includes                                                                  //
#include<iostream>                                                                  //
#include<iomanip>                                                                   //
#include<string>                                                                    //
#include<ctime>                                                                     //
#include<new>                                                                       //
#include<cstddef>                                                                   //
#include<fstream>  // file class functions                                          //
#include<time.h>                                                                    //
#include<stdlib.h>                                                                  //
#ifdef isWindows                                                                    //
#include<direct.h> // for mkdir WINDOWS                                             //
#else                                                                               //
#include<sys/stat.h> // for mkdir UNIX                                              //
#include<unistd.h>                                                                  //
#endif                                                                              //
using namespace std;                                                                //
//====================================================================================



void NC_ControlProgram(ofstream&);
void NC_FrequencyInformations(ostream&, ofstream&);



extern void NC_Read(ofstream&,FILE *,char*,string[],double*);
extern void NC_ReadBasicParametersA(ofstream&,FILE* inputFile_,char*, string[]);
extern int NC_DeclareArrays(ofstream&,double*);
extern void NC_AllocateSDTmtxsSLFMM(ofstream&);
void NC_AllocateSDTmtxsMLFMM(ofstream&);
extern void NC_DeleteArrays(const int&,const int&,const int&);
extern void NC_SetupEquationSystem(ofstream&);
extern void NC_UpdateFreqCurves(ofstream&,double*);
extern void NC_PostProcessing(ofstream&);



// variables declared in NC_ConstantsVariables.h
ofstream NCout;
FILE *inputFile_, *tmpFile_;
char jobTitle_[SIZE_LINE], versionNumber_[15];
int currentFrequency_, numFrequencies_;
double firstFrequencyStep_, frequencyStepIncrement_;
int numElementGroups_, numElements_, numNodes_, minExpansionTermsFMM_, liorcn_, numSymmetricPlanes_, numIncidentPlaneWaves_, numPointSources_,
isInternalProblem_;
double speedOfSound_, densityOfMedium_, harmonicTimeFactor_ = 1.0, waveNumbers_, waveLength_, averageElementArea_, frequency_,
omega1_, rpfact_, Tao_, delta_, epsilon_, ClusEdgL0_;
int numNodesOfBoundaryMesh_, numNodesOfEvaluationMesh_, numElementsOfBoundaryMesh_, numElementsOfEvaluationMesh_, numRowsOfCoefficientMatrix_, numComponentsOfCoefficientMatrix_, numReflectionsOfElements_, numCurvesFrequency_;
int methodBEM_ = 0, numNonZeroEntries_ = 0, numClusterLevels_, nlevtop_,
maxRowNumberD_, numOriginalClusters_, numOriginalReflectedClusters_, numInternalPointsClusters_, methodPreconditioner_, scanningDegreeLU_, methodSolver_;
double farFieldClusterFactor_ = sqrt(5.0)/2.0, minClusterDistance_;
double maxClusterRadiusBE_, avgClusterRadiusBE_, minClusterRadiusBE_, maxClusterRadiusRM_, avgClusterRadiusRM_, minClusterRadiusRM_;
int numExpansionTerms_;
int numIntegrationPointsUnitSphere_, numIntegrationPointsThetaDirection_, numIntegrationPointsPhiDirection_;
int methodFMM_;
bool boolComputeTVector_;
int iMirrSour_ = 0, iSpringMass_ = 0;
double diameterBE_;
int *extNumbersOfNodes, *isNodeMeshOrEvalNode, *extNumbersOfElements;
double **nodesCoordinates;
int **elementsConnectivity;
int *listNumberNodesPerElement, *listElementProperty, *listElementsElementGroup;
int *listSymmetryPlanes;
double *listSymmetryPlanesCoordinates;
int *ibval;
Complex **zbval0, **zbvao0, *zbval1, *zbval2, *zbvao1, *zbvao2;
double **elenor, **centel, *areael;
int **jelist;
int *indexOfElementGroup, *numberOfElementsInGroup, *propertyOfGroup;
int *numinw, *numposo;
double **dirinw, **coorps;
int **inwacurv, **posocurv;
Complex *zinwav, *zposoc, *zinwao, *zposoo;
int **ibvcurv, *nucurv, *npcurv;
double **frqcurv, **faccurv;
ElCluster *clustarry;
IpCluster *ipcluarry;
int *jcolnea, *irownea;
int *jcoltmtx, *irowtmtx;
Complex *ztmtx;
Complex *ztvct;
D_mtx_lev *dmtxlev;
T_mtx_lev *tmtxlev;
S_mtx_lev *smtxlev;
int *jcolsmtx, *irowsmtx;
Complex *zsmtx;
double **uvcsphe;
double *weisphe;
Complex *zcoefl;
Complex *zrhs;
ClusterLev *clulevarry;
ElCluster *ClustArray;



// the main program for NumCalc
int main(int argc, char **argv) 
{
	// compute the start time
	time_t lot = time(NULL);
	tm *d_t = localtime(&lot);

	// Start informations
	cout << "\n---------- NumCalc started: " << d_t->tm_mday << "/" << d_t->tm_mon + 1 <<
		"/" << d_t->tm_year + 1900 << " " << d_t->tm_hour << ":" << d_t->tm_min << 
		":" << d_t->tm_sec << " ----------\n" << endl;
    
#ifdef isWindows

#else
    char Name[150];
    memset(Name, 0, 150);
    gethostname(Name, 150);
    cout << "Running on:         " << Name << "\n" << endl;
#endif

    // open the general output file
	ofstream NCout("NC.out");
	if(!NCout) NC_Error_Exit_0(NCout, "can not open the output stream NCout!");

	// start time
    NCout << "\nStart time: " << d_t->tm_mday << "/" << d_t->tm_mon + 1 << "/" <<
        d_t->tm_year + 1900 << " " << d_t->tm_hour << ":" << d_t->tm_min << ":" <<
        d_t->tm_sec << endl;
    
	// delete and create the output directories
#ifdef isWindows
	int ifmkd;
    if(system("rmdir /s /q be.out")==-1) cout << "\nCannot create directory be.out";
    if(system("rmdir /s /q fe.out")==-1) cout << "\nCannot create directory fe.out";
    ifmkd = _mkdir("be.out"); // WINDOWS
    ifmkd = _mkdir("fe.out");
#else
	if(system("rm -f -r be.out")==-1) cout << "\nCannot create directory be.out";
	if(system("rm -f -r fe.out")==-1) cout << "\nCannot create directory fe.out";
	mkdir("be.out", S_IRUSR | S_IWUSR | S_IXUSR | S_IRGRP | S_IWGRP | S_IXGRP | S_IROTH | S_IXOTH);  // UNIX
	mkdir("fe.out", S_IRUSR | S_IWUSR | S_IXUSR | S_IRGRP | S_IWGRP | S_IXGRP | S_IROTH | S_IXOTH);
#endif
    
	// call the control program
	NC_ControlProgram(NCout);

	// compute the end time
	lot = time(NULL);
	d_t = localtime(&lot);

	// end informations
    NCout << "\nEnd time: " << d_t->tm_mday << "/" << d_t->tm_mon + 1 << "/" <<
        d_t->tm_year + 1900 << " " << d_t->tm_hour << ":" << d_t->tm_min << ":" <<
        d_t->tm_sec << endl;

	cout << "\n---------- NumCalc ended: " << d_t->tm_mday << "/" << d_t->tm_mon + 1 <<
		"/" << d_t->tm_year + 1900 << " " << d_t->tm_hour << ":" << d_t->tm_min << 
		":" << d_t->tm_sec << " ----------" << endl;

	return(0);
}

// control program
void NC_ControlProgram(ofstream& NCout)
{
	double *Freqs = nullptr;

	int i, j, l, nptsouc, ifdiff, terml, npthet, npphi, npsph;
	double rw, rd_max;
	double H_Argum_Min = 0.0; // minimum allowable argument of the spherical Hankel function

	// terms of the input line
	string chterms[NTRM];
	// input line
	char* chinpline = new char[SIZE]; 

	// real time, U. Breymann p 629
	time_t ltim[7], lti_eqa = 0, lti_sol = 0, lti_pos = 0, lti_est, lti_sst, lti_pst;

	time(&ltim[0]);

	// open the input file
	inputFile_ = fopen("NC.inp", "r");
	if(inputFile_) // If input file exists
    {
        // write the basic parameters
        NCout << "\n\n>> G E N E R A L   P A R A M E T E R S <<\n" << endl;
        
		cout << "3D analysis" << endl;
		NCout << "\n3D analysis" << endl;

		// read the basic parameters (part 1)
		NC_ReadBasicParametersA(NCout, inputFile_, chinpline, chterms);

		// create the frequency vector
		Freqs = new double[numFrequencies_];

		// read the input file
		NC_Read(NCout, inputFile_, chinpline, chterms, Freqs);
	}
	else // If input file does not exist
	{
        NC_Error_Exit_0(NCout, "No input file found!");
	}

	// delete the input line
	delete [] chinpline;

	// absolute value of number of the point sources (when numPointSources_ = -1, a "test point source" is generated and used for testing the accuracy of the program)
	nptsouc = abs(numPointSources_);

	time(&ltim[1]);

	// Value of the smallst allowable argument of the spherical Hankel function (the bigst allowable norm of the spherical Hankel function = 3.0e13):
	if(minExpansionTermsFMM_ == 5) {H_Argum_Min = 0.0051;}
	else if(minExpansionTermsFMM_ == 6) {H_Argum_Min = 0.0177;}
	else if(minExpansionTermsFMM_ == 7) {H_Argum_Min = 0.0445;}
	else if(minExpansionTermsFMM_ == 8) {H_Argum_Min = 0.0905;}
	else if(minExpansionTermsFMM_ == 9) {H_Argum_Min = 0.1597;}
	else if(minExpansionTermsFMM_ == 10) {H_Argum_Min = 0.2547;}

	time(&ltim[2]);

	// loop over frequencies
	for(currentFrequency_ = 0; currentFrequency_ < numFrequencies_; currentFrequency_++)
	{

		time(&ltim[3]);

		// compute some parameters
		frequency_ = Freqs[currentFrequency_];					// frequency
		omega1_ = 2.0*PI*frequency_;				// angular frequency
		rpfact_ = densityOfMedium_*omega1_*harmonicTimeFactor_;		// = sound pressure / velocity potential
		waveNumbers_ = omega1_/speedOfSound_;				// wave number
		waveLength_ = speedOfSound_/frequency_;				// wave length
		minClusterDistance_ = H_Argum_Min/waveNumbers_;        // minimum distance between interacting clusters

		// address computations

        // write the step informations
        cout << "\nStep " << currentFrequency_ + 1 << ", Frequency = " << frequency_ << " Hz" << endl;

        NCout << "\n\n\n>> S T E P   N U M B E R   A N D   F R E Q U E N C Y <<\n"
            << endl;
        NCout << "Step " << currentFrequency_ + 1 << ", Frequency = " << frequency_ << " Hz" 
            << endl;

        // address computation
        ifdiff = NC_DeclareArrays(NCout, Freqs);

        // write the analysis type and cluster informations
        if(ifdiff) NC_FrequencyInformations(cout, NCout);

		// Asign some arrays on the finest level to the corresponding actual arrays 
		if(methodFMM_ >= 2 && currentFrequency_ > 0) 
		{
			ClustArray = clulevarry[nlevtop_].ClastArLv;

			numOriginalClusters_ = clulevarry[nlevtop_].nClustOLv;
			numOriginalReflectedClusters_ = clulevarry[nlevtop_].nClustSLv;

			numExpansionTerms_ = clulevarry[nlevtop_].nExpaTermLv;
			numIntegrationPointsUnitSphere_ = clulevarry[nlevtop_].nPoinSpheLv;
			maxClusterRadiusBE_ = clulevarry[nlevtop_].RadiMaxLv;
			avgClusterRadiusBE_ = clulevarry[nlevtop_].RadiAveLv;
			minClusterRadiusBE_ = clulevarry[nlevtop_].RadiMinLv;

			weisphe = clulevarry[nlevtop_].weisphe;
			uvcsphe = clulevarry[nlevtop_].uvcsphe;
		}

        // read the velocity boundary conditions from the output files of the structural analysis

		// If curves are used for prescribing the dependancies of the admittance boundary conditions and the incident waves on the frequencies, adate their walues according to the corresponding curves
		NC_UpdateFreqCurves(NCout, Freqs);

		// Compute parameters for FMBEM (number of the expansion terms, Gauss points at the unit sphere);
		switch(methodFMM_) // = 0: TBEM; 1: SLFMBEM; 3: DMLFMBEM
		{
		case 1: // SLFMBEM
			// order of expension
			rw = 2.0*maxClusterRadiusBE_*waveNumbers_ + 1.8*log10(2.0*maxClusterRadiusBE_*waveNumbers_ + PI);
			numExpansionTerms_ = (int)(rw);
			if(rw - (double)numExpansionTerms_ >= 0.5) numExpansionTerms_++;
			if(numExpansionTerms_ < minExpansionTermsFMM_) numExpansionTerms_ = minExpansionTermsFMM_;

			// number of the Gauss points in the Theta direction
			numIntegrationPointsThetaDirection_ = numExpansionTerms_;

			// number of the Gauss points must not excess the allowable maximum  
			if(numIntegrationPointsThetaDirection_ > N_GAUORDER)
			{
				NC_Error_Exit_2(NCout,
				"Too many integral points in the theta-direction!",
				"Number of integration points = ", numIntegrationPointsThetaDirection_, 
				"Maximum allowable number of integration points = ", N_GAUORDER);
			}

			// number of points in the Phi direction
			numIntegrationPointsPhiDirection_ = 2*numIntegrationPointsThetaDirection_;

			// number of points on the unit sphere
			numIntegrationPointsUnitSphere_ = numIntegrationPointsThetaDirection_*numIntegrationPointsPhiDirection_;
			break;
		case 3: // DMLFMBEM
			cout << endl;
			NCout << endl;
			for(l=0; l<numClusterLevels_; l++)
			{
				// order of expension
				rd_max = clulevarry[l].RadiMaxLv;
				rw = 2.0*rd_max*waveNumbers_ + 1.8*log10(2.0*rd_max*waveNumbers_ + PI);
				terml = (int)(rw);
				if(rw - (double)terml >= 0.5) terml++;
				if(terml < minExpansionTermsFMM_) terml = minExpansionTermsFMM_;
				npthet = clulevarry[l].nExpaTermLv = terml;

				// For the second interpolation scheme of IMLFMBEM, numbers of Gaussean points in the theta-direction on two successive levels must be even at least on one of them
				clulevarry[l].nPoinThetLv = npthet;

				// number of the Gauss points must not excess the allowable maximum  
				if(npthet > N_GAUORDER)
				{
					NC_Error_Exit_2(NCout,
					"Too many integral points in the theta-direction!",
					"Number of integration points = ", npthet, 
					"Maximum allowable number of integration points = ", N_GAUORDER);
				}

				// number of points in the Phi direction
				npphi = 2*npthet;
				clulevarry[l].nPoinPhiLv = npphi;

				// number of points on the unit sphere
				clulevarry[l].nPoinSpheLv = npthet*npphi;
			} // end of loop L

			// Asign some arrays on the finest level to the corresponding actual arrays 
			numExpansionTerms_ = clulevarry[nlevtop_].nExpaTermLv;
			numIntegrationPointsThetaDirection_ = clulevarry[nlevtop_].nPoinThetLv;
			numIntegrationPointsPhiDirection_ = clulevarry[nlevtop_].nPoinPhiLv;
			numIntegrationPointsUnitSphere_ = clulevarry[nlevtop_].nPoinSpheLv;
			break;
		default:
			break;
		} // end of SWITCH

		// write infomations about FFM expansion and integration points on the unit sphere
		if(methodFMM_) {
			cout << "\nInformations about the FMM expansion:" << endl;
			cout <<
				"   Level    N. expa. terms    N. p. theta    N. p. phi    N. p. sphere"
				<< endl;
			NCout << "\nInformations about the FMM expansion:" << endl;
			NCout <<
				"   Level    N. expa. terms    N. p. theta    N. p. phi    N. p. sphere"
				<< endl;
			for(l=0; l<numClusterLevels_; l++) {
				if(methodFMM_ == 1) {
					terml = numExpansionTerms_;
					npthet = numIntegrationPointsThetaDirection_;
					npphi = numIntegrationPointsPhiDirection_;
					npsph = numIntegrationPointsUnitSphere_;
				} else {
					terml = clulevarry[l].nExpaTermLv;
					npthet = clulevarry[l].nPoinThetLv;
					npphi = clulevarry[l].nPoinPhiLv;
					npsph = clulevarry[l].nPoinSpheLv;
				}
				cout << "   " << setw(3) << l << "       " << setw(5) << terml <<
					"           " << setw(5) << npthet << 
					"           " << setw(5) << npphi << 
					"         " << setw(5) << npsph << endl;
				NCout << "   " << setw(3) << l << "       " << setw(5) << terml <<
					"           " << setw(5) << npthet << 
					"           " << setw(5) << npphi << 
					"         " << setw(5) << npsph << endl;
			}
		}

		// initialize the right hand side vector
		for(i=0; i<numRowsOfCoefficientMatrix_; i++)
        {
            zrhs[i].set(0.0, 0.0);
        }

        // generate and initialize the coefficient matrices
		switch(methodFMM_)
		{
		case 0: // TBEM
			// create and initialize the coefficient matrices
			zcoefl = new Complex[numComponentsOfCoefficientMatrix_];
			for(i=0; i<numComponentsOfCoefficientMatrix_; i++) zcoefl[i].set(0.0, 0.0);
			break;
		case 1: // SLFMBEM
			// compute the auxiliary arrays used for storing the sparse far field matrices
			NC_AllocateSDTmtxsSLFMM(NCout);

			// coordinates and weights of the integration points on the unit sphere
			uvcsphe = new double*[numIntegrationPointsUnitSphere_];
			for(i=0; i<numIntegrationPointsUnitSphere_; i++)
			{
				uvcsphe[i] = new double[NDIM];
			}
			weisphe = new double[numIntegrationPointsUnitSphere_];

			// generate the "T-vector" ( = [T] * {x})
			if(boolComputeTVector_) ztvct = new Complex[numIntegrationPointsUnitSphere_*numOriginalReflectedClusters_];

			// generate and initialize the near field matrix
			zcoefl = new Complex[irownea[numRowsOfCoefficientMatrix_]];
			for(i=0; i<irownea[numRowsOfCoefficientMatrix_]; i++) zcoefl[i].set(0.0, 0.0);

			// generate the "T-matrix" ([T])
			ztmtx = new Complex[irowtmtx[numOriginalReflectedClusters_*numIntegrationPointsUnitSphere_]];

			// generate the "D-matrix" ([D])
			dmtxlev[0].zDmxLv = new Complex[dmtxlev[0].nEntriesD];

			// generate he "S-matrix" ([S])
			zsmtx = new Complex[irowsmtx[numRowsOfCoefficientMatrix_]];

			break;
		case 3: // DMLFMBEM
			// compute the auxiliary arrays used for storing the sparse far field matrices
			NC_AllocateSDTmtxsMLFMM(NCout);

			// create and initialize the near field matrix
			zcoefl = new Complex[irownea[numRowsOfCoefficientMatrix_]];
			for(i=0; i<irownea[numRowsOfCoefficientMatrix_]; i++) zcoefl[i].set(0.0, 0.0);

			// loop over levels
			for(j=0; j<numClusterLevels_; j++)
			{
				// number of the integration points on the unit sphere
				int nthej = clulevarry[j].nPoinThetLv;
				int npsh = clulevarry[j].nPoinSpheLv;

				// create the working arrays for the T- and S-matrices
				clulevarry[j].zwkT = new Complex[clulevarry[j].nClustSLv*npsh];
				clulevarry[j].zwkS = new Complex[clulevarry[j].nClustOLv*npsh];

				// create the arrays of coordinates and weights of the integral points on the unit sphere
				clulevarry[j].uvcsphe = new double*[npsh];
				for(i=0; i<npsh; i++) clulevarry[j].uvcsphe[i] = new double[NDIM];
				clulevarry[j].weisphe = new double[npsh];

				// create the arrays of the coorninates and weights of the Gauss points in the theta-direction
				clulevarry[j].CrdGauLv = new double[nthej];
				clulevarry[j].WeiGauLv = new double[nthej];

				// create the T-matrix and the T-vector, the D- and S-matrices
				tmtxlev[j].zTmxLv = new Complex[tmtxlev[j].nEntriesT];
				if(boolComputeTVector_) tmtxlev[j].zTvcLv = new Complex[clulevarry[j].nClustSLv*npsh];
				dmtxlev[j].zDmxLv = new Complex[dmtxlev[j].nEntriesD];
				smtxlev[j].zSmxLv = new Complex[smtxlev[j].nEntriesS];
			}

			break;
		} // end of SWITCH

		// set up the equation system
        NC_SetupEquationSystem(NCout);

		time(&ltim[4]);
		lti_est = ltim[4] - ltim[3];
		lti_eqa += lti_est;

		// solve the equation system
		switch(methodSolver_)
		{
		case 0: // CGS method
			NC_IterativeSolverCGS(NCout);
			break;
		case 4: // direct method, usable only to the TBEM factorize the coefficient matrix
			Tfactor_usy(zcoefl, numRowsOfCoefficientMatrix_);

			// forward substitution and backward eliminations
			Tfbelim(zcoefl, zrhs, numRowsOfCoefficientMatrix_);
			break;
		}

		// destroy the coefficient matrices 
		delete [] zcoefl;

		switch(methodFMM_)
		{
		case 1:
			delete [] jcoltmtx;
			delete [] irowtmtx;

			delete [] jcolsmtx;
			delete [] irowsmtx;

			delete [] zsmtx;
			delete [] ztmtx;
			if(boolComputeTVector_) delete [] ztvct;
			break;
		case 3:
			if(boolComputeTVector_)
			{
				for(j=0; j<numClusterLevels_; j++) delete [] tmtxlev[j].zTvcLv;
			}
			for(j=0; j<numClusterLevels_; j++)
			{
				delete [] tmtxlev[j].jcolTmxLv;
				delete [] tmtxlev[j].irowTmxLv;
				delete [] tmtxlev[j].zTmxLv;

				delete [] smtxlev[j].jcolSmxLv;
				delete [] smtxlev[j].irowSmxLv;
				delete [] smtxlev[j].zSmxLv;
			}
			break;
		}

		time(&ltim[5]);
		lti_sst = ltim[5] - ltim[4];
		lti_sol += lti_sst;

		// post process: compute and output the results
        NC_PostProcessing(NCout);

		switch(methodFMM_)
		{
		case 1: // SLFMBEM
			for(i=0; i<numIntegrationPointsUnitSphere_; i++) delete [] uvcsphe[i];
			delete [] uvcsphe;
			delete [] weisphe;

			delete [] dmtxlev[0].jcolDmxLv;
			delete [] dmtxlev[0].irowDmxLv;
			delete [] dmtxlev[0].zDmxLv;
			break;
		case 3: // DMLFMBEM
			for(j=0; j<numClusterLevels_; j++)
			{
				delete [] clulevarry[j].CrdGauLv;
				delete [] clulevarry[j].WeiGauLv;

				for(i=0; i<clulevarry[j].nPoinSpheLv; i++) delete [] clulevarry[j].uvcsphe[i];
				delete [] clulevarry[j].uvcsphe;
				delete [] clulevarry[j].weisphe;

				delete [] clulevarry[j].zwkT;
				delete [] clulevarry[j].zwkS;


				delete [] dmtxlev[j].jcolDmxLv;
				delete [] dmtxlev[j].irowDmxLv;
				delete [] dmtxlev[j].zDmxLv;
			}
			break;
		}

		time(&ltim[6]);
		lti_pst = ltim[6] - ltim[5];
		lti_pos += lti_pst;

		// time statistic for the current frequency
        NCout << "\nTime Statistic For The Current Step (In Second)\n" << endl;
        NCout << "Assembling the equation system         : " << lti_est << endl;
        NCout << "Solving the equation system            : " << lti_sst << endl;
        NCout << "Post processing                        : " << lti_pst << endl;
        NCout << "Total                                  : " << 
            lti_est + lti_sst + lti_pst << endl;

        cout << "Assembling the equation system         : " << lti_est << endl;
        cout << "Solving the equation system            : " << lti_sst << endl;
        cout << "Post processing                        : " << lti_pst << endl;
        cout << "Total                                  : " << 
            lti_est + lti_sst + lti_pst << endl;
        cout << endl;

		// delete arrays generated by 3-d address computations
		if(currentFrequency_ == numFrequencies_ - 1)  NC_DeleteArrays(methodFMM_, numClusterLevels_, 1);

	} // end of loop I_FREQ (Loop over Frequencies)

    NCout << "\n\n\n>> T I M E   S T A T I S T I C   (In   Second) <<\n" << endl;
    NCout << "Input                                  : " << ltim[1] - ltim[0] << endl;
    NCout << "Address computation                    : " << ltim[2] - ltim[1] << endl;
    NCout << "Assembling the equation system         : " << lti_eqa << endl;
    NCout << "Solving the equation system            : " << lti_sol << endl;
    NCout << "Post processing                        : " << lti_pos << endl;
    NCout << "The whole job                          : " << ltim[6] - ltim[0] << endl;

	cout << "\nTime Statistic for the job (in second):" << endl;
	cout << "Input ............................ " << ltim[1] - ltim[0] << endl;
	cout << "Address computation .............. " << ltim[2] - ltim[1] << endl;
	cout << "Assembling the equation system ... " << lti_eqa << endl;
	cout << "Solving the equation system ...... " << lti_sol << endl;
	cout << "Post processing .................. " << lti_pos << endl;
	cout << "The whole job .................... " << ltim[6] - ltim[0] << endl;

	// delete
	delete [] extNumbersOfNodes;
	delete [] isNodeMeshOrEvalNode;
	delete [] extNumbersOfElements;

	for(i=0; i<numNodes_; i++) delete [] nodesCoordinates[i];
	delete [] nodesCoordinates;

	for(i=0; i<numElements_; i++) delete [] elementsConnectivity[i];
	delete [] elementsConnectivity;

	delete [] listNumberNodesPerElement;
	delete [] listElementProperty;
	delete [] listElementsElementGroup;

	delete [] listSymmetryPlanes;
	delete [] listSymmetryPlanesCoordinates;

	delete [] ibval;
	for(i=0; i<numElements_; i++) delete [] zbval0[i];
	delete [] zbval0;
	for(i=0; i<numElements_; i++) delete [] zbvao0[i];
	delete [] zbvao0;
	delete [] zbval1;
	delete [] zbval2;
	delete [] zbvao1;
	delete [] zbvao2;

	for(i=0; i<numElements_; i++) delete [] elenor[i];
	delete [] elenor;
	for(i=0; i<numElements_; i++) delete [] centel[i];
	delete [] centel;
	delete [] areael;
	for(i=0; i<numElements_; i++) delete [] jelist[i];
	delete [] jelist;

	delete [] indexOfElementGroup;
	delete [] numberOfElementsInGroup;
	delete [] propertyOfGroup;

	delete [] numinw;
	delete [] numposo;
	for(i=0; i<numIncidentPlaneWaves_; i++) delete [] dirinw[i];
	delete [] dirinw;
	for(i=0; i<nptsouc; i++) delete [] coorps[i];
	delete [] coorps;
	for(i=0; i<numIncidentPlaneWaves_; i++) delete [] inwacurv[i];
	delete [] inwacurv;
	for(i=0; i<nptsouc; i++) delete [] posocurv[i];
	delete [] posocurv;
	delete [] zinwav;
	delete [] zposoc;
	delete [] zinwao;
	delete [] zposoo;

	for(i=0; i<numElements_; i++) delete [] ibvcurv[i];
	delete [] ibvcurv;
	delete [] nucurv;
	delete [] npcurv;
	for(i=0; i<numCurvesFrequency_; i++) delete [] frqcurv[i];
	delete [] frqcurv;
	for(i=0; i<numCurvesFrequency_; i++) delete [] faccurv[i];
	delete [] faccurv;
    
    delete [] Freqs;
}

// output informations
void NC_FrequencyInformations
(
	ostream& xout,
	ofstream& yout
)
{
	int i, n;
	double r_min, r_max;

	switch(methodFMM_)
	{
	case 0: 
		xout << "\nTraditional BEM" << endl;
		break;
	case 1: 
		xout << "\nSingle level fast multipole BEM" << endl;
		break;
	case 3: 
		xout << "\nDirect multilevel fast multipole BEM" << endl;
		break;
	}

	// write the parameters of the equation system
	if(currentFrequency_ == 0)
	{
		xout << "\nNumber of equations = " << numRowsOfCoefficientMatrix_  << endl;
		if(methodFMM_ == 0) {
			xout << "Number of entries of the coefficient matrix = " << numComponentsOfCoefficientMatrix_ << endl;
		}
	}

	// write infomations of clusters
	if(methodFMM_) {
		xout << "\nInformations about clusters:" << endl;
		xout << "   Level    Num. of clusters    Maximum radius   Minimum radius" << endl;
		for(i=0; i<numClusterLevels_; i++) {
			if(methodFMM_ == 1) {
				n = numOriginalClusters_;
				r_max = maxClusterRadiusBE_;
				r_min = minClusterRadiusBE_;
			} else {
				n = clulevarry[i].nClustOLv;
				r_max = clulevarry[i].RadiMaxLv;
				r_min = clulevarry[i].RadiMinLv;
			}
			xout << "   " << setw(3) << i << "       " << setw(6) << n 
				<< "                " << setw(6) << r_max 
				<< "         " << setw(6) << r_min << endl;
		}
		if(numInternalPointsClusters_) {
			xout << " resu. nets" << "  " << setw(6) << numInternalPointsClusters_ << 
				"                " << setw(6) << maxClusterRadiusRM_  << 
				"         " << setw(6) << minClusterRadiusRM_ << endl;
		}
	}

	switch(methodFMM_)
	{
	case 0: 
		yout << "\nTraditional BEM" << endl;
		break;
	case 1: 
		yout << "\nSingle level fast multipole BEM" << endl;
		break;
	case 3: 
		yout << "\nDirect multilevel fast multipole BEM" << endl;
		break;
	}

	// write the parameters of the equation system
	if(currentFrequency_ == 0)
	{
		yout << "\nNumber of equations = " << numRowsOfCoefficientMatrix_  << endl;
		if(methodFMM_ == 0) {
			yout << "Number of entries of the coefficient matrix = " << numComponentsOfCoefficientMatrix_ << endl;
		}
	}

	// write infomations of clusters
	if(methodFMM_) {
		yout << "\nInformations about clusters:" << endl;
		yout << "   Level    Num. of clusters    Maximum radius   Minimum radius" << endl;
		for(i=0; i<numClusterLevels_; i++) {
			if(methodFMM_ == 1) {
				n = numOriginalClusters_;
				r_max = maxClusterRadiusBE_;
				r_min = minClusterRadiusBE_;
			} else {
				n = clulevarry[i].nClustOLv;
				r_max = clulevarry[i].RadiMaxLv;
				r_min = clulevarry[i].RadiMinLv;
			}
			yout << "   " << setw(3) << i << "       " << setw(6) << n 
				<< "                " << setw(6) << r_max 
				<< "         " << setw(6) << r_min << endl;
		}
		if(numInternalPointsClusters_) {
			yout << " resu. nets" << "  " << setw(6) << numInternalPointsClusters_ << 
				"                " << setw(6) << maxClusterRadiusRM_  << 
				"         " << setw(6) << minClusterRadiusRM_ << endl;
		}
	}
}
