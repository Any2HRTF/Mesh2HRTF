This is the place for user generated evaluation grids.

They can for example be generated with the Matlab tools under
PreProcessing/EvaluationGrid(Matlab)/demo.m